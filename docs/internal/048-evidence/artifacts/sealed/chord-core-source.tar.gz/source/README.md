# @chord/core

Experimental JavaScript/ES-module kernel for host-governed coordination, atomic single-process state transitions, attempt-bound approvals and versioned committed-state replay.

## Quickstart (5–10 min)

```bash
cd packages/core
bun install
bun test
node examples/cross-actor-workflow.mjs
```

The canonical example demonstrates:
- Two independent mock actors (Builder/Reviewer) coordinating via handoff
- Bounded context projection filtered by exact active task grants (no automatic content redaction)
- Protected action → approval pause → cross-session resume
- Deterministic trace replay with zero side effects

## Supported engines
Locally verified: Bun 1.3.14 and Node.js 26.7.0 (ESM). Other versions have not been verified by this correction gate.

## Public API
```js
import { createChord } from '@chord/core';
```
SDK methods include `registerSpecAndQueue`, `queueTaskPackets`, `runCycle`, `projectContext`, `proposeHandoff`, `respondToHandoff`, `pauseForApproval`, `resumeRun`, `cancelRun`, `reconcileTask`, `exportRegistry`, `inspectAudit` and `inspectEvents`.

Import `importRegistry`, `replayNoSideEffects`, `reduceTrace`, `diffTraces`, `canonicalProjection` and `SCHEMA_VERSION` from `@chord/core`. `importRegistry` and replay functions are not SDK instance methods. See [integrity and migration](INTEGRITY.md) before embedding the host SDK or restoring state.

## Limitations
- **In-memory by default**: No built-in durable storage. Use export/import for session boundaries (trusted-host).
- **Experimental preview**: API not stable. Low-level exports remain trusted-host.
- **No sandbox**: Adapters run in-process.
- **No universal exactly-once**: External effects cannot be universally guaranteed.
- **No cryptographic tamper-proofing**: Trace is append-only structurally but not cryptographically signed.

## Tests
```bash
bun test
```
